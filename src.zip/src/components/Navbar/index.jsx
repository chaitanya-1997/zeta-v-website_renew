import { useState, useEffect } from 'react'
import './Navbar.css'
import logoImage from './ZETAV-LOGO-zv.png' // Adjust the path as needed

const navLinks = ['About', 'Industries', 'Services', 'Journey', 'Careers', 'Contact']

export default function Navbar() {
    const [scrolled, setScrolled] = useState(false)
    const [menuOpen, setMenuOpen] = useState(false)

    useEffect(() => {
        const onScroll = () => setScrolled(window.scrollY > 60)
        window.addEventListener('scroll', onScroll, { passive: true })
        return () => window.removeEventListener('scroll', onScroll)
    }, [])

    const handleLinkClick = (e, link) => {
        e.preventDefault()
        const id = link.toLowerCase()
        const el = document.getElementById(id)
        if (el) el.scrollIntoView({ behavior: 'smooth' })
        setMenuOpen(false)
    }

    return (
        <header className={`navbar${scrolled ? ' navbar--scrolled' : ''}`}>
            <div className="navbar__inner">
                {/* Logo */}
                <a href="/" className="navbar__logo">
                    <img 
                        src={logoImage} 
                        alt="Zeta-V Logo" 
                        className="navbar__logo-mark"
                    />
                    <span className="navbar__wordmark">ZETA-V</span>
                </a>

                {/* Desktop Nav */}
                <nav className="navbar__links">
                    {navLinks.map(link => (
                        <a
                            key={link}
                            href={`#${link.toLowerCase()}`}
                            className="navbar__link"
                            onClick={e => handleLinkClick(e, link)}
                        >
                            {link}
                        </a>
                    ))}
                </nav>

                {/* CTA */}
                <a href="#contact" className="navbar__cta btn-grad" onClick={e => handleLinkClick(e, 'Contact')}>
                    Let's Talk
                </a>

                {/* Hamburger */}
                <button
                    className={`navbar__hamburger${menuOpen ? ' open' : ''}`}
                    onClick={() => setMenuOpen(o => !o)}
                    aria-label="Toggle menu"
                >
                    <span /><span /><span />
                </button>
            </div>

            {/* Mobile Menu */}
            <div className={`navbar__mobile${menuOpen ? ' navbar__mobile--open' : ''}`}>
                {navLinks.map((link, i) => (
                    <a
                        key={link}
                        href={`#${link.toLowerCase()}`}
                        className="navbar__mobile-link"
                        style={{ animationDelay: menuOpen ? `${i * 80}ms` : '0ms' }}
                        onClick={e => handleLinkClick(e, link)}
                    >
                        {link}
                    </a>
                ))}
                <a href="#contact" className="btn-grad navbar__mobile-cta" onClick={e => handleLinkClick(e, 'Contact')}>
                    Let's Talk
                </a>
            </div>
        </header>
    )
}