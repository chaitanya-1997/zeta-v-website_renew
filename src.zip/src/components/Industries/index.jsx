import { useState, useEffect } from 'react'
import { useReveal } from '../../hooks/useReveal'
import './Industries.css'

// Custom SVG Icons
const IndustryIcons = {
  financial: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M3 6H21V8H3V6ZM4 9H6V17H4V9ZM9 9H11V17H9V9ZM14 9H16V17H14V9ZM19 9H21V17H19V9Z" fill="currentColor"/>
      <path d="M2 19H22V21H2V19Z" fill="currentColor"/>
      <rect x="6" y="3" width="12" height="2" fill="currentColor"/>
      <path d="M12 11L8 14H16L12 11Z" fill="currentColor" opacity="0.7"/>
    </svg>
  ),
  manufacturing: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M20 9L12 3L4 9V19H20V9Z" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M12 7V13M12 13L9 10.5M12 13L15 10.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <path d="M8 15H16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <path d="M6 19H18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <circle cx="12" cy="16" r="1" fill="currentColor"/>
    </svg>
  ),
  healthcare: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M12 4V20M4 12H20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M7 12H17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <path d="M12 7V17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  government: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M4 10V16L12 21L20 16V10" stroke="currentColor" strokeWidth="1.5" fill="none"/>
      <path d="M12 12V21" stroke="currentColor" strokeWidth="1.5"/>
      <circle cx="12" cy="15.5" r="1" fill="currentColor"/>
    </svg>
  ),
  arrowRight: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  check: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M20 6L9 17L4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  play: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M10 8L16 12L10 16V8Z" fill="currentColor"/>
    </svg>
  ),
  pause: () => (
    <svg viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="9" y="8" width="2" height="8" fill="currentColor"/>
      <rect x="13" y="8" width="2" height="8" fill="currentColor"/>
    </svg>
  )
}

const industries = [
  {
    icon: IndustryIcons.financial,
    title: 'Financial Services',
    desc: 'Driving fintech innovation through secure cloud migration, advanced data analytics, AI-powered fraud detection, and cybersecurity consulting.',
    color: '#0D47A1',
    tag: 'Fintech & Banking',
    gradient: 'linear-gradient(135deg, #0D47A1, #1565C0)'
  },
  {
    icon: IndustryIcons.manufacturing,
    title: 'Manufacturing',
    desc: 'Enabling smart factories with IoT, machine learning, DevOps pipelines, cloud migration, and robotic process automation.',
    color: '#7C3AED',
    tag: 'Smart Factory',
    gradient: 'linear-gradient(135deg, #7C3AED, #A855F7)'
  },
  {
    icon: IndustryIcons.healthcare,
    title: 'Healthcare',
    desc: 'Accelerating digital transformation in patient care through telemedicine platforms, secure patient data systems, and AI-driven healthcare analytics.',
    color: '#DB2777',
    tag: 'Digital Health',
    gradient: 'linear-gradient(135deg, #DB2777, #EC4899)'
  },
  {
    icon: IndustryIcons.government,
    title: 'Government',
    desc: 'Modernizing public services with scalable digital integration, secure cloud infrastructure, citizen-centric platforms, and cybersecurity services.',
    color: '#EA580C',
    tag: 'Public Sector',
    gradient: 'linear-gradient(135deg, #EA580C, #F97316)'
  },
]

export default function IndustriesSection() {
  const [active, setActive] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [headRef, headVisible] = useReveal(0)

  // Auto-rotate every 4 seconds
  useEffect(() => {
    if (!isAutoPlaying) return
    
    const interval = setInterval(() => {
      setActive((prev) => (prev + 1) % industries.length)
    }, 4000)
    
    return () => clearInterval(interval)
  }, [isAutoPlaying])

  const handleManualChange = (index) => {
    setActive(index)
    setIsAutoPlaying(false)
    // Resume auto-play after 8 seconds of inactivity
    setTimeout(() => setIsAutoPlaying(true), 8000)
  }

  return (
    <section id="industries" className="industries">
      <div className="industries__bg">
        <div className="bg-grid"></div>
        <div className="bg-gradient-1"></div>
        <div className="bg-gradient-2"></div>
      </div>

      <div className="industries__inner">
        <div ref={headRef} className={`industries__head reveal${headVisible ? ' visible' : ''}`}>
          <span className="section-label">Industries We Serve</span>
          
          <h2 className="section-title">
            Technology Solutions Tailored for <span className="gradient-highlight">Every Industry</span>
          </h2>
          <p className="section-subtitle">
            We help organizations modernize operations, enhance customer experiences, and build resilient digital infrastructure across various industries.
          </p>
        </div>

        <div className="industries__layout">
          {/* Left sticky panel */}
          <div className="industries__panel">
            <div className="industries__panel-icon">
              <IndustryIcons.check />
            </div>
            <p className="industries__panel-desc">
              Our consultants bring deep domain expertise to every engagement — delivering solutions that drive real business outcomes across industries.
            </p>
            
            {/* Auto-play controller */}
            <div className="auto-play-control">
              <button 
                className={`auto-play-btn ${isAutoPlaying ? 'playing' : ''}`}
                onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              >
                {isAutoPlaying ? <IndustryIcons.pause /> : <IndustryIcons.play />}
                <span>{isAutoPlaying ? 'Auto-rotate ON' : 'Auto-rotate OFF'}</span>
              </button>
            </div>

            <div className="industries__list">
              {industries.map((ind, i) => {
                const IconComponent = ind.icon
                return (
                  <button
                    key={i}
                    className={`industries__list-item ${active === i ? 'active' : ''}`}
                    onClick={() => handleManualChange(i)}
                    style={active === i ? { borderLeftColor: ind.color } : {}}
                  >
                    <span className="industries__list-icon" style={{ color: ind.color }}>
                      <IconComponent />
                    </span>
                    <span className="industries__list-text">{ind.title}</span>
                    {active === i && <span className="active-dot" style={{ background: ind.color }}></span>}
                  </button>
                )
              })}
            </div>

            {/* Progress bar for auto-rotate */}
            {isAutoPlaying && (
              <div className="auto-progress">
                <div className="progress-bar" key={active}>
                  <div className="progress-fill"></div>
                </div>
              </div>
            )}

            <div className="industries__stats">
              <div className="stat">
                <span className="stat-number">100+</span>
                <span className="stat-label">Industry Projects</span>
              </div>
              <div className="stat">
                <span className="stat-number">12+</span>
                <span className="stat-label">Industries Served</span>
              </div>
              <div className="stat">
                <span className="stat-number">90%+</span>
                <span className="stat-label">Client Retention</span>
              </div>
            </div>
          </div>

          {/* Right card grid - 4 cards visible */}
          <div className="industries__grid">
            {industries.map((ind, i) => {
              const [ref, visible] = useReveal(i * 150)
              const IconComponent = ind.icon
              const isActive = active === i
              
              return (
                <div
                  key={i}
                  ref={ref}
                  className={`industries__card reveal${visible ? ' visible' : ''} ${isActive ? 'active' : ''}`}
                  onClick={() => handleManualChange(i)}
                  style={{ 
                    transitionDelay: `${i * 100}ms`,
                    cursor: 'pointer'
                  }}
                >
                  {/* Active glow effect */}
                  {isActive && <div className="active-glow" style={{ background: ind.color }}></div>}
                  
                  {/* Animated border for active card */}
                  {isActive && <div className="active-border" style={{ borderColor: ind.color }}></div>}
                  
                  <div className="card-inner">
                    <div className="industries__card-header">
                      <div className="industries__icon-wrapper" style={{ background: `${ind.color}15`, color: ind.color }}>
                        <div className="industries__icon">
                          <IconComponent />
                        </div>
                      </div>
                      <div className="industries__card-badge">
                        <span className="badge-number">0{i + 1}</span>
                      </div>
                    </div>
                    
                    <div className="card-tag" style={{ background: `${ind.color}10`, color: ind.color }}>
                      {ind.tag}
                    </div>
                    
                    <h3 className="industries__card-title">{ind.title}</h3>
                    <p className="industries__card-desc">{ind.desc}</p>
                    
                    <div className="industries__card-footer">
                      <a href="#industries" className="industries__card-link" style={{ color: ind.color }}>
                        <span>Learn more</span>
                        <span className="link-icon">
                          <IndustryIcons.arrowRight />
                        </span>
                      </a>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* CTA below industries */}
        <div className="industries__cta-wrapper">
          <a href="#contact" className="industries__cta-btn">
            Explore Industry Solutions →
          </a>
        </div>

        {/* Slider indicators */}
        <div className="slider-indicators">
          {industries.map((_, i) => (
            <button
              key={i}
              className={`slider-dot ${active === i ? 'active' : ''}`}
              onClick={() => handleManualChange(i)}
              style={active === i ? { background: industries[i].color } : {}}
            />
          ))}
        </div>
      </div>
    </section>
  )
}